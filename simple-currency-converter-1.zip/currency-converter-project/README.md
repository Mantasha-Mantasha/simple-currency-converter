# Simple Currency Converter

A beginner-friendly Python project to convert currencies such as PKR, USD, EUR, GBP, SAR, and AED.

## Features
- Fetches the latest available exchange rates from a public endpoint.
- Does not require an API key.
- Supports manual exchange-rate entry if the live service is unavailable.
- Validates amount input and prints the conversion clearly.
- Includes a Google Colab notebook.

## Files
- `main.py` — run the converter in a terminal or VS Code.
- `currency_converter_colab.ipynb` — run the project in Google Colab.
- `requirements.txt` — no third-party packages are required.

## Run in VS Code
1. Install Python 3.
2. Open this folder in VS Code.
3. Open the terminal.
4. Run:

   ```bash
   python main.py
   ```

5. Enter the source currency, target currency, and amount.

## Run in Google Colab
1. Open https://colab.research.google.com/
2. Choose **File → Upload notebook**.
3. Upload `currency_converter_colab.ipynb`.
4. Run the cells from top to bottom.
5. Enter the currency codes and amount when prompted.

## Publish on GitHub
1. Create a new repository named `simple-currency-converter`.
2. Upload `main.py`, this README, `requirements.txt`, and the notebook.
3. Do not upload private API keys. This project does not need one.

## Important note
Exchange rates change. The API provides the latest available rates, not necessarily the exact rate offered by a bank, money exchanger, or card provider. The converter is for learning and estimates only.
