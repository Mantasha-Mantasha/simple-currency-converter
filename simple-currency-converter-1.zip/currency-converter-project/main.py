"""
Simple Currency Converter
- Uses a public exchange-rate endpoint (no API key required).
- If internet access is unavailable, users can choose manual-rate mode.
"""

import json
import urllib.request
import urllib.error

API_URL = "https://open.er-api.com/v6/latest/{base}"


def get_rates(base_currency):
    """Fetch rates for a base currency. Returns a dictionary or None."""
    url = API_URL.format(base=base_currency.upper())
    request = urllib.request.Request(
        url,
        headers={"User-Agent": "SimpleCurrencyConverter/1.0"}
    )
    try:
        with urllib.request.urlopen(request, timeout=10) as response:
            data = json.loads(response.read().decode("utf-8"))
        if data.get("result") == "success":
            return data.get("rates", {})
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
        print(f"Could not retrieve live rates: {exc}")
    return None


def convert(amount, rate):
    """Convert amount using the rate: target units per 1 source unit."""
    return amount * rate


def main():
    print("=" * 42)
    print("          SIMPLE CURRENCY CONVERTER")
    print("=" * 42)
    print("Example currency codes: PKR, USD, EUR, GBP, SAR, AED")
    source = input("Convert FROM (e.g., USD): ").strip().upper()
    target = input("Convert TO (e.g., PKR): ").strip().upper()

    if not source or not target or len(source) != 3 or len(target) != 3:
        print("Please enter valid 3-letter currency codes.")
        return

    try:
        amount = float(input(f"Amount in {source}: ").strip())
        if amount < 0:
            print("Amount must be zero or greater.")
            return
    except ValueError:
        print("Please enter a valid number for the amount.")
        return

    rates = get_rates(source)
    if rates and target in rates:
        rate = rates[target]
        print("\nRate source: open.er-api.com (latest available rate)")
    else:
        print("\nLive rate unavailable for this currency or connection.")
        print("Enter a rate manually (target units for 1 source unit).")
        try:
            rate = float(input(f"1 {source} = how many {target}? "))
            if rate < 0:
                print("Rate must be zero or greater.")
                return
        except ValueError:
            print("Please enter a valid number for the rate.")
            return
        print("Rate source: manually entered by user")

    result = convert(amount, rate)
    print("\n--------- RESULT ---------")
    print(f"{amount:,.2f} {source} = {result:,.2f} {target}")
    print(f"Exchange rate used: 1 {source} = {rate:,.6f} {target}")
    print("Note: actual bank/card rates and fees may differ.")


if __name__ == "__main__":
    main()
